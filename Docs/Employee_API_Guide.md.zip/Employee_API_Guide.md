# دليل API للموظفين - نظام إدارة الدوام

## معلومات عامة

**Base URL**: `http://localhost:5151` (أو عنوان الخادم في الإنتاج)

**Authentication**: جميع الـEndpoints (ما عدا تسجيل الدخول) تتطلب JWT Token في Header:
```
Authorization: Bearer {your_token}
```

---

## 1. تسجيل الدخول

### تسجيل الدخول والحصول على التوكن
**Endpoint**: `POST /auth/login`

**الوصف**: تسجيل دخول الموظف للحصول على JWT Token لاستخدامه في جميع الطلبات التالية

**Authentication**: غير مطلوب

**Request Body**:
```json
{
  "username": "ahmed",
  "password": "password123"
}
```

**Response (200 OK)**:
```json
{
  "accessToken": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
  "refreshToken": "guid-string",
  "expiresAt": "2024-11-28T15:30:00Z",
  "username": "ahmed",
  "role": "Employee"
}
```

**كيفية الاستخدام**:
1. أرسل اسم المستخدم وكلمة المرور
2. احفظ `accessToken` من الرد
3. استخدم هذا التوكن في جميع الطلبات التالية في Header: `Authorization: Bearer {accessToken}`
4. `expiresAt` يحدد وقت انتهاء صلاحية التوكن - قم بتسجيل الدخول مرة أخرى عند انتهاء الصلاحية

**Errors**:
- `401 Unauthorized`: اسم المستخدم أو كلمة المرور غير صحيحة

---

## 2. تسجيل الدخول والخروج من الدوام

### 2.1 تسجيل دخول الدوام (Check-In)
**Endpoint**: `POST /api/attendance/check-in`

**الوصف**: تسجيل دخولك في يوم عمل معين مع وقت الدخول

**Authentication**: مطلوب (JWT Token)

**Request Body**:
```json
{
  "workDate": "2024-11-28",
  "checkInTime": "07:30",
  "timeOffMinutesUsed": 0,
  "notes": "تسجيل دخول"
}
```

**الحقول**:
- `workDate` (مطلوب): تاريخ العمل بصيغة `YYYY-MM-DD` (مثال: "2024-11-28")
- `checkInTime` (مطلوب): وقت الدخول بصيغة `HH:mm` (مثال: "07:30" أو "08:15")
- `timeOffMinutesUsed` (اختياري): عدد دقائق الزمنية المستخدمة لتغطية التأخير (افتراضي: 0)
- `notes` (اختياري): ملاحظات إضافية

**Response (200 OK)**:
```json
{
  "id": 1,
  "workDate": "2024-11-28",
  "checkIn": "07:30",
  "checkOut": "14:00",
  "timeOffMinutesUsed": 0,
  "delayMinutes": 30,
  "overtimeMinutes": 0,
  "ninetyMinutesDeducted": 30,
  "notes": "تسجيل دخول",
  "isLocked": false
}
```

**ما يحدث تلقائياً**:
- النظام يحسب التأخير تلقائياً (وقت الدخول - 07:00)
- إذا كان هناك تأخير، يتم خصم أول 90 دقيقة من رصيد الـ90 دقيقة
- يتم تحديث الملخص الشهري تلقائياً

**قواعد مهمة**:
- ❌ لا يمكن التسجيل في يوم الجمعة أو السبت (عطلة)
- ❌ لا يمكن التسجيل مرتين في نفس اليوم
- ✅ يمكنك تعديل سجل اليوم الحالي فقط (قبل نهاية اليوم)

**Errors**:
- `400 Bad Request`: إذا كان اليوم جمعة أو سبت، أو إذا كان السجل موجود مسبقاً
- `401 Unauthorized`: إذا كان التوكن غير صالح

---

### 2.2 تسجيل خروج الدوام (Check-Out)
**Endpoint**: `POST /api/attendance/check-out`

**الوصف**: تسجيل خروجك وتحديث وقت الخروج

**Authentication**: مطلوب (JWT Token)

**Request Body**:
```json
{
  "workDate": "2024-11-28",
  "checkOutTime": "14:30",
  "notes": "تسجيل خروج"
}
```

**الحقول**:
- `workDate` (مطلوب): نفس تاريخ تسجيل الدخول
- `checkOutTime` (مطلوب): وقت الخروج بصيغة `HH:mm`
- `notes` (اختياري): ملاحظات إضافية

**Response (200 OK)**:
```json
{
  "id": 1,
  "workDate": "2024-11-28",
  "checkIn": "07:30",
  "checkOut": "14:30",
  "timeOffMinutesUsed": 0,
  "delayMinutes": 30,
  "overtimeMinutes": 30,
  "ninetyMinutesDeducted": 30,
  "notes": "تسجيل خروج",
  "isLocked": false
}
```

**ما يحدث تلقائياً**:
- النظام يحسب الإضافي تلقائياً (وقت الخروج - 14:00)
- يتم تحديث الملخص الشهري تلقائياً

**قواعد مهمة**:
- ⚠️ يجب أن يكون هناك سجل دخول (check-in) مسبقاً في نفس اليوم
- ✅ يمكنك تعديل وقت الخروج في نفس اليوم

**Errors**:
- `404 Not Found`: إذا لم يكن هناك سجل دخول في هذا اليوم
- `400 Bad Request`: إذا كان السجل مقفولاً (لا يمكن التعديل)

---

## 3. إضافة زمنية

### إضافة زمنية لتغطية التأخير
**Endpoint**: `POST /api/attendance/time-off`

**الوصف**: إضافة زمنية لتغطية التأخير أو استخدامها لأغراض أخرى. الزمنية تُخصم من رصيدك الشهري (7 ساعات)

**Authentication**: مطلوب (JWT Token)

**Request Body**:
```json
{
  "timeOffDate": "2024-11-28",
  "minutesUsed": 30,
  "reason": "تغطية تأخير"
}
```

**الحقول**:
- `timeOffDate` (مطلوب): تاريخ الزمنية بصيغة `YYYY-MM-DD`
- `minutesUsed` (مطلوب): عدد الدقائق المستخدمة (يُخصم من 7 ساعات الزمنيات)
- `reason` (مطلوب): سبب استخدام الزمنية

**Response (200 OK)**:
```json
{
  "success": true,
  "message": "Time off added successfully. 30 minutes deducted from monthly balance."
}
```

**مثال عملي**:
إذا تأخرت 30 دقيقة (دخلت الساعة 07:30 بدلاً من 07:00) وأضفت زمنية 30 دقيقة:
- ✅ لا يتم خصم من رصيد الـ90 دقيقة
- ✅ يتم استعادة أي خصم سابق من 90 دقيقة
- ✅ يتم الخصم من 7 ساعات الزمنيات فقط

**قواعد مهمة**:
- ✅ الحد الأقصى للزمنية اليومية: 4 ساعات (240 دقيقة)
- ❌ لا يمكن إضافة زمنية في يوم الجمعة أو السبت
- ⚠️ يجب أن يكون لديك رصيد كافي من الزمنيات (7 ساعات = 420 دقيقة شهرياً)

**Errors**:
- `400 Bad Request`: 
  - إذا كان الرصيد غير كافي
  - إذا كان اليوم جمعة أو سبت
  - إذا تجاوزت 240 دقيقة في اليوم

---

## 4. عرض رصيدي

### جلب رصيدي من الزمنيات والـ90 دقيقة
**Endpoint**: `GET /api/employees/me/balance`

**الوصف**: عرض رصيدك الحالي من الزمنيات والـ90 دقيقة لهذا الشهر

**Authentication**: مطلوب (JWT Token)

**Response (200 OK)**:
```json
{
  "employeeId": 1,
  "employeeName": "أحمد محمد",
  "monthlyTimeOffBalance": 390,
  "ninetyMinutesBalance": 60,
  "year": 2024,
  "month": 11,
  "totalTimeOffUsed": 30,
  "remainingTimeOffMinutes": 390
}
```

**شرح الحقول**:
- `monthlyTimeOffBalance`: الرصيد المتبقي من الزمنيات (بالدقائق) - هذا ما تبقى لك من 7 ساعات
- `ninetyMinutesBalance`: الرصيد المتبقي من الـ90 دقيقة - يُخصم عند التأخير
- `totalTimeOffUsed`: إجمالي الزمنيات المستخدمة هذا الشهر
- `remainingTimeOffMinutes`: نفس `monthlyTimeOffBalance` (المتبقي)

**مثال**:
- إذا كان `monthlyTimeOffBalance = 390`، يعني أنك استخدمت 30 دقيقة من 420 دقيقة (7 ساعات)
- إذا كان `ninetyMinutesBalance = 60`، يعني أنك استخدمت 30 دقيقة من 90 دقيقة

---

## 5. عرض سجلاتي الشهرية

### جلب سجلات الحضور لشهر معين
**Endpoint**: `GET /api/attendance/{employeeId}/{year}/{month}?includeLocked=false`

**الوصف**: عرض جميع سجلات الحضور الخاصة بك في شهر معين

**Authentication**: مطلوب (JWT Token)

**Path Parameters**:
- `employeeId`: معرفك (يُؤخذ من التوكن تلقائياً)
- `year`: السنة (مثال: 2024)
- `month`: الشهر (1-12)

**Query Parameters**:
- `includeLocked` (اختياري): تضمين السجلات المقفولة (افتراضي: false)

**Response (200 OK)**:
```json
[
  {
    "id": 1,
    "workDate": "2024-11-01",
    "checkIn": "07:30",
    "checkOut": "14:00",
    "timeOffMinutesUsed": 0,
    "delayMinutes": 30,
    "overtimeMinutes": 0,
    "ninetyMinutesDeducted": 30,
    "notes": null,
    "isLocked": false
  },
  {
    "id": 2,
    "workDate": "2024-11-02",
    "checkIn": "07:00",
    "checkOut": "14:30",
    "timeOffMinutesUsed": 0,
    "delayMinutes": 0,
    "overtimeMinutes": 30,
    "ninetyMinutesDeducted": 0,
    "notes": null,
    "isLocked": false
  }
]
```

**شرح الحقول**:
- `delayMinutes`: دقائق التأخير
- `overtimeMinutes`: دقائق الإضافي
- `ninetyMinutesDeducted`: ما تم خصمه من رصيد الـ90 دقيقة
- `isLocked`: إذا كان `true`، لا يمكن تعديل السجل

---

## 6. عرض ملخصي الشهري

### جلب ملخصي الشهري
**Endpoint**: `GET /api/summary/{employeeId}/{year}/{month}`

**الوصف**: عرض ملخصك الشهري الكامل (إجمالي التأخير، الإضافي، الزمنيات، إلخ)

**Authentication**: مطلوب (JWT Token)

**Path Parameters**:
- `employeeId`: معرفك
- `year`: السنة
- `month`: الشهر (1-12)

**Response (200 OK)**:
```json
{
  "employeeId": 1,
  "employeeName": "أحمد محمد",
  "year": 2024,
  "month": 11,
  "totalTimeOffMinutesUsed": 30,
  "totalDelayMinutes": 120,
  "ninetyMinutesConsumed": 90,
  "remainingTimeOffMinutes": 390,
  "remainingNinetyMinutes": 0,
  "totalOvertimeMinutes": 60,
  "calculatedAt": "2024-11-28T10:00:00Z"
}
```

**شرح الحقول**:
- `totalTimeOffMinutesUsed`: إجمالي الزمنيات المستخدمة هذا الشهر
- `totalDelayMinutes`: إجمالي دقائق التأخير الفعلي (بعد خصم 90 دقيقة)
- `ninetyMinutesConsumed`: ما تم استهلاكه من رصيد الـ90 دقيقة
- `remainingTimeOffMinutes`: المتبقي من الزمنيات (7 ساعات)
- `remainingNinetyMinutes`: المتبقي من الـ90 دقيقة
- `totalOvertimeMinutes`: إجمالي دقائق الإضافي

---

## سيناريو كامل: يوم عمل عادي

### الخطوة 1: تسجيل الدخول للنظام
```bash
POST /auth/login
{
  "username": "ahmed",
  "password": "password123"
}
# احفظ accessToken
```

### الخطوة 2: تسجيل دخول الدوام
```bash
POST /api/attendance/check-in
Authorization: Bearer {token}
{
  "workDate": "2024-11-28",
  "checkInTime": "07:30",
  "timeOffMinutesUsed": 0,
  "notes": "تسجيل دخول"
}
# النتيجة: تأخير 30 دقيقة، خصم 30 دقيقة من 90 دقيقة
```

### الخطوة 3: إضافة زمنية لتغطية التأخير (اختياري)
```bash
POST /api/attendance/time-off
Authorization: Bearer {token}
{
  "timeOffDate": "2024-11-28",
  "minutesUsed": 30,
  "reason": "تغطية تأخير"
}
# النتيجة: استعادة 30 دقيقة من 90 دقيقة، خصم 30 دقيقة من الزمنيات
```

### الخطوة 4: تسجيل خروج الدوام
```bash
POST /api/attendance/check-out
Authorization: Bearer {token}
{
  "workDate": "2024-11-28",
  "checkOutTime": "14:30",
  "notes": "تسجيل خروج"
}
# النتيجة: إضافي 30 دقيقة
```

### الخطوة 5: التحقق من الرصيد
```bash
GET /api/employees/me/balance
Authorization: Bearer {token}
# النتيجة: رصيدك المتبقي من الزمنيات والـ90 دقيقة
```

---

## قواعد مهمة للموظف

### ✅ ما يمكنك فعله:
- تسجيل دخول وخروج الدوام يومياً
- إضافة زمنية لتغطية التأخير
- عرض سجلاتك الشهرية
- عرض ملخصك الشهري
- عرض رصيدك من الزمنيات والـ90 دقيقة
- تعديل سجل اليوم الحالي فقط

### ❌ ما لا يمكنك فعله:
- تسجيل الدخول في يوم الجمعة أو السبت
- إضافة زمنية في يوم الجمعة أو السبت
- تسجيل دخول مرتين في نفس اليوم
- تعديل سجلات الأيام السابقة
- رؤية سجلات موظفين آخرين
- الوصول إلى لوحة التحكم أو إدارة الموظفين

### 📊 الرصيد الشهري:
- **الزمنيات**: 7 ساعات (420 دقيقة) - تُجدد كل شهر
- **الـ90 دقيقة**: 90 دقيقة - تُجدد كل شهر
- **الزمنية اليومية**: لا تتجاوز 4 ساعات (240 دقيقة) في اليوم

### ⏰ أوقات الدوام:
- **بداية الدوام**: 07:00
- **نهاية الدوام**: 14:00
- **التأخير**: يُحسب من (وقت الدخول - 07:00)
- **الإضافي**: يُحسب من (وقت الخروج - 14:00)

---

## رموز الحالة (Status Codes)

- `200 OK`: العملية نجحت ✅
- `400 Bad Request`: خطأ في البيانات المرسلة (مثال: يوم جمعة/سبت، رصيد غير كافي) ⚠️
- `401 Unauthorized`: التوكن غير صالح أو غير موجود - قم بتسجيل الدخول مرة أخرى 🔒
- `404 Not Found`: العنصر غير موجود (مثال: لا يوجد سجل دخول في هذا اليوم) ❌

---

## نصائح للمطور

1. **إدارة التوكن**:
   - احفظ التوكن بشكل آمن (مثلاً: SecureStorage في Flutter)
   - راقب `expiresAt` وقم بتسجيل الدخول مرة أخرى عند انتهاء الصلاحية
   - أضف التوكن في Header: `Authorization: Bearer {token}`

2. **التاريخ والوقت**:
   - التاريخ: صيغة `YYYY-MM-DD` (مثال: "2024-11-28")
   - الوقت: صيغة `HH:mm` (مثال: "07:30" أو "14:15")

3. **معالجة الأخطاء**:
   - تحقق من رموز الحالة ومعالجتها بشكل مناسب
   - اعرض رسائل خطأ واضحة للمستخدم

4. **التحديث التلقائي**:
   - الرصيد والملخصات تُحدّث تلقائياً عند تسجيل الدخول/الخروج أو إضافة زمنية
   - لا حاجة لتحديث يدوي

5. **التحقق من الرصيد**:
   - تحقق من الرصيد قبل إضافة زمنية
   - اعرض الرصيد المتبقي للمستخدم

---

## أمثلة على الاستخدام في الكود

### Flutter/Dart Example:
```dart
// تسجيل الدخول
final response = await http.post(
  Uri.parse('http://localhost:5151/auth/login'),
  headers: {'Content-Type': 'application/json'},
  body: jsonEncode({
    'username': 'ahmed',
    'password': 'password123',
  }),
);

final data = jsonDecode(response.body);
final token = data['accessToken'];

// تسجيل دخول الدوام
final checkInResponse = await http.post(
  Uri.parse('http://localhost:5151/api/attendance/check-in'),
  headers: {
    'Content-Type': 'application/json',
    'Authorization': 'Bearer $token',
  },
  body: jsonEncode({
    'workDate': '2024-11-28',
    'checkInTime': '07:30',
    'timeOffMinutesUsed': 0,
    'notes': 'تسجيل دخول',
  }),
);
```

### JavaScript/React Example:
```javascript
// تسجيل الدخول
const loginResponse = await fetch('http://localhost:5151/auth/login', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({
    username: 'ahmed',
    password: 'password123'
  })
});

const loginData = await loginResponse.json();
const token = loginData.accessToken;

// تسجيل دخول الدوام
const checkInResponse = await fetch('http://localhost:5151/api/attendance/check-in', {
  method: 'POST',
  headers: {
    'Content-Type': 'application/json',
    'Authorization': `Bearer ${token}`
  },
  body: JSON.stringify({
    workDate: '2024-11-28',
    checkInTime: '07:30',
    timeOffMinutesUsed: 0,
    notes: 'تسجيل دخول'
  })
});
```

---

**آخر تحديث**: نوفمبر 2024

